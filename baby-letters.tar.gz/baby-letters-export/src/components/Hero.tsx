import { useState } from "react";
import { Needle, PaintBrushBroad, MapPin, InstagramLogo } from "@phosphor-icons/react";

export default function Hero() {
  return (
    <section
      style={{
        minHeight: "70vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        padding: "20px",
        marginTop: "50px",
      }}
    >
      <div
        style={{
          width: "160px",
          height: "160px",
          borderRadius: "50%",
          border: "3px solid #d4af37",
          marginBottom: "20px",
          boxShadow: "0 0 30px rgba(212, 175, 55, 0.35)",
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <img
          src="/brhenda-profile.jpg"
          alt="Brhenda Rodrigues"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center 45%",
            filter: "contrast(1.1) brightness(1.05) saturate(1.1)",
            transform: "scale(1.0)",
          }}
        />
      </div>

      <h2
        className="gothic-font"
        style={{ fontSize: "2.8rem", marginBottom: "10px", lineHeight: 1.1 }}
      >
        Lettering &amp; Arte Urbana
      </h2>

      <p
        style={{
          color: "#a3a3a3",
          fontSize: "1.1rem",
          maxWidth: "500px",
          marginBottom: "20px",
        }}
      >
        Especialista em caligrafia personalizada e tattoos exclusivas em Jundiaí - SP.
      </p>

      <InstagramButton />

      <div
        style={{
          display: "flex",
          gap: "10px",
          justifyContent: "center",
          flexWrap: "wrap",
          marginBottom: "30px",
          marginTop: "20px",
        }}
      >
        <Tag icon={<Needle size={14} weight="fill" />} label="Lettering Pro" />
        <Tag icon={<PaintBrushBroad size={14} weight="fill" />} label="Graffiti Artist" />
        <Tag icon={<MapPin size={14} weight="fill" />} label="Cartel Tattoos" />
      </div>
    </section>
  );
}

function InstagramButton() {
  const [hovered, setHovered] = useState(false);

  return (
    <a
      href="https://www.instagram.com/baby.letters"
      target="_blank"
      rel="noopener noreferrer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "8px",
        padding: "10px 22px",
        borderRadius: "24px",
        background: hovered
          ? "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)"
          : "transparent",
        border: "1.5px solid",
        borderColor: hovered ? "transparent" : "#555",
        color: hovered ? "#fff" : "#a3a3a3",
        textDecoration: "none",
        fontSize: "0.9rem",
        fontWeight: 600,
        transition: "all 0.3s ease",
        marginBottom: "4px",
        letterSpacing: "0.3px",
      }}
    >
      <InstagramLogo size={18} weight="fill" />
      @baby.letters
    </a>
  );
}

function Tag({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span
      style={{
        background: "#171717",
        padding: "5px 15px",
        borderRadius: "20px",
        fontSize: "0.9rem",
        border: "1px solid #333",
        display: "flex",
        alignItems: "center",
        gap: "6px",
      }}
    >
      {icon}
      {label}
    </span>
  );
}
