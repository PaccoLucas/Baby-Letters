# Baby Letters — Como rodar no VSCode

## Requisitos
- [Node.js](https://nodejs.org/) versão 18 ou superior
- [pnpm](https://pnpm.io/) — instale com: `npm install -g pnpm`

## Passos

1. Abra a pasta `baby-letters` no VSCode
2. Abra o terminal integrado (Ctrl + `)
3. Instale as dependências:
   ```
   pnpm install
   ```
4. Rode o site:
   ```
   pnpm dev
   ```
5. Acesse no navegador: **http://localhost:5173**

## Pronto! O site abre automaticamente.
